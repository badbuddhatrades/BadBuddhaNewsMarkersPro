#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BadBuddha_NewsMarkersPRO[] cacheBadBuddha_NewsMarkersPRO;

		
		public BadBuddha_NewsMarkersPRO BadBuddha_NewsMarkersPRO(NinjaTrader.NinjaScript.BBCountdownClock countdownClock, NinjaTrader.NinjaScript.BBTradingMode tradingMode, string csvFileName, int autoReloadMinutes, bool forceCSVDownload, string flagFolderName, int pastDays, int futureDays, bool showVerticalLines, int vLineOpacityPct, int vLineThicknessPx, bool showEventLabels, bool showCountdownLabels, int labelTitleMaxChars, bool enableBlackoutHigh, int highPreMinutes, int highPostMinutes, bool enableBlackoutMedium, int medPreMinutes, int medPostMinutes, int blackoutOpacityPct, bool enableCurrencyFilter, bool showUSD, bool showEUR, bool showGBP, bool showAUD, bool showNZD, bool showCAD, bool showCHF, bool showJPY, bool showCNY, bool enableUpdateCheck, bool showUpdatePopup, bool showEventsTable, BBTableDisplayMode tableDisplay, int tableMaxRows, int tableWidthPx, int tableRowHeightPx, int tableOpacityPct, NinjaTrader.NinjaScript.BBTableCorner tableCorner, int tableTitleMaxChars, int tableVerticalOffsetPx, bool showTableDataColumns, bool enableAlerts, bool alertHighImpact, bool alertMediumImpact, string alertWindowsCsv, string alertSoundFile, NinjaTrader.NinjaScript.Priority alertPriority, bool alertOnlyDuringTradingHours)
		{
			return BadBuddha_NewsMarkersPRO(Input, countdownClock, tradingMode, csvFileName, autoReloadMinutes, forceCSVDownload, flagFolderName, pastDays, futureDays, showVerticalLines, vLineOpacityPct, vLineThicknessPx, showEventLabels, showCountdownLabels, labelTitleMaxChars, enableBlackoutHigh, highPreMinutes, highPostMinutes, enableBlackoutMedium, medPreMinutes, medPostMinutes, blackoutOpacityPct, enableCurrencyFilter, showUSD, showEUR, showGBP, showAUD, showNZD, showCAD, showCHF, showJPY, showCNY, enableUpdateCheck, showUpdatePopup, showEventsTable, tableDisplay, tableMaxRows, tableWidthPx, tableRowHeightPx, tableOpacityPct, tableCorner, tableTitleMaxChars, tableVerticalOffsetPx, showTableDataColumns, enableAlerts, alertHighImpact, alertMediumImpact, alertWindowsCsv, alertSoundFile, alertPriority, alertOnlyDuringTradingHours);
		}


		
		public BadBuddha_NewsMarkersPRO BadBuddha_NewsMarkersPRO(ISeries<double> input, NinjaTrader.NinjaScript.BBCountdownClock countdownClock, NinjaTrader.NinjaScript.BBTradingMode tradingMode, string csvFileName, int autoReloadMinutes, bool forceCSVDownload, string flagFolderName, int pastDays, int futureDays, bool showVerticalLines, int vLineOpacityPct, int vLineThicknessPx, bool showEventLabels, bool showCountdownLabels, int labelTitleMaxChars, bool enableBlackoutHigh, int highPreMinutes, int highPostMinutes, bool enableBlackoutMedium, int medPreMinutes, int medPostMinutes, int blackoutOpacityPct, bool enableCurrencyFilter, bool showUSD, bool showEUR, bool showGBP, bool showAUD, bool showNZD, bool showCAD, bool showCHF, bool showJPY, bool showCNY, bool enableUpdateCheck, bool showUpdatePopup, bool showEventsTable, BBTableDisplayMode tableDisplay, int tableMaxRows, int tableWidthPx, int tableRowHeightPx, int tableOpacityPct, NinjaTrader.NinjaScript.BBTableCorner tableCorner, int tableTitleMaxChars, int tableVerticalOffsetPx, bool showTableDataColumns, bool enableAlerts, bool alertHighImpact, bool alertMediumImpact, string alertWindowsCsv, string alertSoundFile, NinjaTrader.NinjaScript.Priority alertPriority, bool alertOnlyDuringTradingHours)
		{
			if (cacheBadBuddha_NewsMarkersPRO != null)
				for (int idx = 0; idx < cacheBadBuddha_NewsMarkersPRO.Length; idx++)
					if (cacheBadBuddha_NewsMarkersPRO[idx].CountdownClock == countdownClock && cacheBadBuddha_NewsMarkersPRO[idx].TradingMode == tradingMode && cacheBadBuddha_NewsMarkersPRO[idx].CsvFileName == csvFileName && cacheBadBuddha_NewsMarkersPRO[idx].AutoReloadMinutes == autoReloadMinutes && cacheBadBuddha_NewsMarkersPRO[idx].ForceCSVDownload == forceCSVDownload && cacheBadBuddha_NewsMarkersPRO[idx].FlagFolderName == flagFolderName && cacheBadBuddha_NewsMarkersPRO[idx].PastDays == pastDays && cacheBadBuddha_NewsMarkersPRO[idx].FutureDays == futureDays && cacheBadBuddha_NewsMarkersPRO[idx].ShowVerticalLines == showVerticalLines && cacheBadBuddha_NewsMarkersPRO[idx].VLineOpacityPct == vLineOpacityPct && cacheBadBuddha_NewsMarkersPRO[idx].VLineThicknessPx == vLineThicknessPx && cacheBadBuddha_NewsMarkersPRO[idx].ShowEventLabels == showEventLabels && cacheBadBuddha_NewsMarkersPRO[idx].ShowCountdownLabels == showCountdownLabels && cacheBadBuddha_NewsMarkersPRO[idx].LabelTitleMaxChars == labelTitleMaxChars && cacheBadBuddha_NewsMarkersPRO[idx].EnableBlackoutHigh == enableBlackoutHigh && cacheBadBuddha_NewsMarkersPRO[idx].HighPreMinutes == highPreMinutes && cacheBadBuddha_NewsMarkersPRO[idx].HighPostMinutes == highPostMinutes && cacheBadBuddha_NewsMarkersPRO[idx].EnableBlackoutMedium == enableBlackoutMedium && cacheBadBuddha_NewsMarkersPRO[idx].MedPreMinutes == medPreMinutes && cacheBadBuddha_NewsMarkersPRO[idx].MedPostMinutes == medPostMinutes && cacheBadBuddha_NewsMarkersPRO[idx].BlackoutOpacityPct == blackoutOpacityPct && cacheBadBuddha_NewsMarkersPRO[idx].EnableCurrencyFilter == enableCurrencyFilter && cacheBadBuddha_NewsMarkersPRO[idx].ShowUSD == showUSD && cacheBadBuddha_NewsMarkersPRO[idx].ShowEUR == showEUR && cacheBadBuddha_NewsMarkersPRO[idx].ShowGBP == showGBP && cacheBadBuddha_NewsMarkersPRO[idx].ShowAUD == showAUD && cacheBadBuddha_NewsMarkersPRO[idx].ShowNZD == showNZD && cacheBadBuddha_NewsMarkersPRO[idx].ShowCAD == showCAD && cacheBadBuddha_NewsMarkersPRO[idx].ShowCHF == showCHF && cacheBadBuddha_NewsMarkersPRO[idx].ShowJPY == showJPY && cacheBadBuddha_NewsMarkersPRO[idx].ShowCNY == showCNY && cacheBadBuddha_NewsMarkersPRO[idx].EnableUpdateCheck == enableUpdateCheck && cacheBadBuddha_NewsMarkersPRO[idx].ShowUpdatePopup == showUpdatePopup && cacheBadBuddha_NewsMarkersPRO[idx].ShowEventsTable == showEventsTable && cacheBadBuddha_NewsMarkersPRO[idx].TableDisplay == tableDisplay && cacheBadBuddha_NewsMarkersPRO[idx].TableMaxRows == tableMaxRows && cacheBadBuddha_NewsMarkersPRO[idx].TableWidthPx == tableWidthPx && cacheBadBuddha_NewsMarkersPRO[idx].TableRowHeightPx == tableRowHeightPx && cacheBadBuddha_NewsMarkersPRO[idx].TableOpacityPct == tableOpacityPct && cacheBadBuddha_NewsMarkersPRO[idx].TableCorner == tableCorner && cacheBadBuddha_NewsMarkersPRO[idx].TableTitleMaxChars == tableTitleMaxChars && cacheBadBuddha_NewsMarkersPRO[idx].TableVerticalOffsetPx == tableVerticalOffsetPx && cacheBadBuddha_NewsMarkersPRO[idx].ShowTableDataColumns == showTableDataColumns && cacheBadBuddha_NewsMarkersPRO[idx].EnableAlerts == enableAlerts && cacheBadBuddha_NewsMarkersPRO[idx].AlertHighImpact == alertHighImpact && cacheBadBuddha_NewsMarkersPRO[idx].AlertMediumImpact == alertMediumImpact && cacheBadBuddha_NewsMarkersPRO[idx].AlertWindowsCsv == alertWindowsCsv && cacheBadBuddha_NewsMarkersPRO[idx].AlertSoundFile == alertSoundFile && cacheBadBuddha_NewsMarkersPRO[idx].AlertPriority == alertPriority && cacheBadBuddha_NewsMarkersPRO[idx].AlertOnlyDuringTradingHours == alertOnlyDuringTradingHours && cacheBadBuddha_NewsMarkersPRO[idx].EqualsInput(input))
						return cacheBadBuddha_NewsMarkersPRO[idx];
			return CacheIndicator<BadBuddha_NewsMarkersPRO>(new BadBuddha_NewsMarkersPRO(){ CountdownClock = countdownClock, TradingMode = tradingMode, CsvFileName = csvFileName, AutoReloadMinutes = autoReloadMinutes, ForceCSVDownload = forceCSVDownload, FlagFolderName = flagFolderName, PastDays = pastDays, FutureDays = futureDays, ShowVerticalLines = showVerticalLines, VLineOpacityPct = vLineOpacityPct, VLineThicknessPx = vLineThicknessPx, ShowEventLabels = showEventLabels, ShowCountdownLabels = showCountdownLabels, LabelTitleMaxChars = labelTitleMaxChars, EnableBlackoutHigh = enableBlackoutHigh, HighPreMinutes = highPreMinutes, HighPostMinutes = highPostMinutes, EnableBlackoutMedium = enableBlackoutMedium, MedPreMinutes = medPreMinutes, MedPostMinutes = medPostMinutes, BlackoutOpacityPct = blackoutOpacityPct, EnableCurrencyFilter = enableCurrencyFilter, ShowUSD = showUSD, ShowEUR = showEUR, ShowGBP = showGBP, ShowAUD = showAUD, ShowNZD = showNZD, ShowCAD = showCAD, ShowCHF = showCHF, ShowJPY = showJPY, ShowCNY = showCNY, EnableUpdateCheck = enableUpdateCheck, ShowUpdatePopup = showUpdatePopup, ShowEventsTable = showEventsTable, TableDisplay = tableDisplay, TableMaxRows = tableMaxRows, TableWidthPx = tableWidthPx, TableRowHeightPx = tableRowHeightPx, TableOpacityPct = tableOpacityPct, TableCorner = tableCorner, TableTitleMaxChars = tableTitleMaxChars, TableVerticalOffsetPx = tableVerticalOffsetPx, ShowTableDataColumns = showTableDataColumns, EnableAlerts = enableAlerts, AlertHighImpact = alertHighImpact, AlertMediumImpact = alertMediumImpact, AlertWindowsCsv = alertWindowsCsv, AlertSoundFile = alertSoundFile, AlertPriority = alertPriority, AlertOnlyDuringTradingHours = alertOnlyDuringTradingHours }, input, ref cacheBadBuddha_NewsMarkersPRO);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BadBuddha_NewsMarkersPRO BadBuddha_NewsMarkersPRO(NinjaTrader.NinjaScript.BBCountdownClock countdownClock, NinjaTrader.NinjaScript.BBTradingMode tradingMode, string csvFileName, int autoReloadMinutes, bool forceCSVDownload, string flagFolderName, int pastDays, int futureDays, bool showVerticalLines, int vLineOpacityPct, int vLineThicknessPx, bool showEventLabels, bool showCountdownLabels, int labelTitleMaxChars, bool enableBlackoutHigh, int highPreMinutes, int highPostMinutes, bool enableBlackoutMedium, int medPreMinutes, int medPostMinutes, int blackoutOpacityPct, bool enableCurrencyFilter, bool showUSD, bool showEUR, bool showGBP, bool showAUD, bool showNZD, bool showCAD, bool showCHF, bool showJPY, bool showCNY, bool enableUpdateCheck, bool showUpdatePopup, bool showEventsTable, BBTableDisplayMode tableDisplay, int tableMaxRows, int tableWidthPx, int tableRowHeightPx, int tableOpacityPct, NinjaTrader.NinjaScript.BBTableCorner tableCorner, int tableTitleMaxChars, int tableVerticalOffsetPx, bool showTableDataColumns, bool enableAlerts, bool alertHighImpact, bool alertMediumImpact, string alertWindowsCsv, string alertSoundFile, NinjaTrader.NinjaScript.Priority alertPriority, bool alertOnlyDuringTradingHours)
		{
			return indicator.BadBuddha_NewsMarkersPRO(Input, countdownClock, tradingMode, csvFileName, autoReloadMinutes, forceCSVDownload, flagFolderName, pastDays, futureDays, showVerticalLines, vLineOpacityPct, vLineThicknessPx, showEventLabels, showCountdownLabels, labelTitleMaxChars, enableBlackoutHigh, highPreMinutes, highPostMinutes, enableBlackoutMedium, medPreMinutes, medPostMinutes, blackoutOpacityPct, enableCurrencyFilter, showUSD, showEUR, showGBP, showAUD, showNZD, showCAD, showCHF, showJPY, showCNY, enableUpdateCheck, showUpdatePopup, showEventsTable, tableDisplay, tableMaxRows, tableWidthPx, tableRowHeightPx, tableOpacityPct, tableCorner, tableTitleMaxChars, tableVerticalOffsetPx, showTableDataColumns, enableAlerts, alertHighImpact, alertMediumImpact, alertWindowsCsv, alertSoundFile, alertPriority, alertOnlyDuringTradingHours);
		}


		
		public Indicators.BadBuddha_NewsMarkersPRO BadBuddha_NewsMarkersPRO(ISeries<double> input , NinjaTrader.NinjaScript.BBCountdownClock countdownClock, NinjaTrader.NinjaScript.BBTradingMode tradingMode, string csvFileName, int autoReloadMinutes, bool forceCSVDownload, string flagFolderName, int pastDays, int futureDays, bool showVerticalLines, int vLineOpacityPct, int vLineThicknessPx, bool showEventLabels, bool showCountdownLabels, int labelTitleMaxChars, bool enableBlackoutHigh, int highPreMinutes, int highPostMinutes, bool enableBlackoutMedium, int medPreMinutes, int medPostMinutes, int blackoutOpacityPct, bool enableCurrencyFilter, bool showUSD, bool showEUR, bool showGBP, bool showAUD, bool showNZD, bool showCAD, bool showCHF, bool showJPY, bool showCNY, bool enableUpdateCheck, bool showUpdatePopup, bool showEventsTable, BBTableDisplayMode tableDisplay, int tableMaxRows, int tableWidthPx, int tableRowHeightPx, int tableOpacityPct, NinjaTrader.NinjaScript.BBTableCorner tableCorner, int tableTitleMaxChars, int tableVerticalOffsetPx, bool showTableDataColumns, bool enableAlerts, bool alertHighImpact, bool alertMediumImpact, string alertWindowsCsv, string alertSoundFile, NinjaTrader.NinjaScript.Priority alertPriority, bool alertOnlyDuringTradingHours)
		{
			return indicator.BadBuddha_NewsMarkersPRO(input, countdownClock, tradingMode, csvFileName, autoReloadMinutes, forceCSVDownload, flagFolderName, pastDays, futureDays, showVerticalLines, vLineOpacityPct, vLineThicknessPx, showEventLabels, showCountdownLabels, labelTitleMaxChars, enableBlackoutHigh, highPreMinutes, highPostMinutes, enableBlackoutMedium, medPreMinutes, medPostMinutes, blackoutOpacityPct, enableCurrencyFilter, showUSD, showEUR, showGBP, showAUD, showNZD, showCAD, showCHF, showJPY, showCNY, enableUpdateCheck, showUpdatePopup, showEventsTable, tableDisplay, tableMaxRows, tableWidthPx, tableRowHeightPx, tableOpacityPct, tableCorner, tableTitleMaxChars, tableVerticalOffsetPx, showTableDataColumns, enableAlerts, alertHighImpact, alertMediumImpact, alertWindowsCsv, alertSoundFile, alertPriority, alertOnlyDuringTradingHours);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BadBuddha_NewsMarkersPRO BadBuddha_NewsMarkersPRO(NinjaTrader.NinjaScript.BBCountdownClock countdownClock, NinjaTrader.NinjaScript.BBTradingMode tradingMode, string csvFileName, int autoReloadMinutes, bool forceCSVDownload, string flagFolderName, int pastDays, int futureDays, bool showVerticalLines, int vLineOpacityPct, int vLineThicknessPx, bool showEventLabels, bool showCountdownLabels, int labelTitleMaxChars, bool enableBlackoutHigh, int highPreMinutes, int highPostMinutes, bool enableBlackoutMedium, int medPreMinutes, int medPostMinutes, int blackoutOpacityPct, bool enableCurrencyFilter, bool showUSD, bool showEUR, bool showGBP, bool showAUD, bool showNZD, bool showCAD, bool showCHF, bool showJPY, bool showCNY, bool enableUpdateCheck, bool showUpdatePopup, bool showEventsTable, BBTableDisplayMode tableDisplay, int tableMaxRows, int tableWidthPx, int tableRowHeightPx, int tableOpacityPct, NinjaTrader.NinjaScript.BBTableCorner tableCorner, int tableTitleMaxChars, int tableVerticalOffsetPx, bool showTableDataColumns, bool enableAlerts, bool alertHighImpact, bool alertMediumImpact, string alertWindowsCsv, string alertSoundFile, NinjaTrader.NinjaScript.Priority alertPriority, bool alertOnlyDuringTradingHours)
		{
			return indicator.BadBuddha_NewsMarkersPRO(Input, countdownClock, tradingMode, csvFileName, autoReloadMinutes, forceCSVDownload, flagFolderName, pastDays, futureDays, showVerticalLines, vLineOpacityPct, vLineThicknessPx, showEventLabels, showCountdownLabels, labelTitleMaxChars, enableBlackoutHigh, highPreMinutes, highPostMinutes, enableBlackoutMedium, medPreMinutes, medPostMinutes, blackoutOpacityPct, enableCurrencyFilter, showUSD, showEUR, showGBP, showAUD, showNZD, showCAD, showCHF, showJPY, showCNY, enableUpdateCheck, showUpdatePopup, showEventsTable, tableDisplay, tableMaxRows, tableWidthPx, tableRowHeightPx, tableOpacityPct, tableCorner, tableTitleMaxChars, tableVerticalOffsetPx, showTableDataColumns, enableAlerts, alertHighImpact, alertMediumImpact, alertWindowsCsv, alertSoundFile, alertPriority, alertOnlyDuringTradingHours);
		}


		
		public Indicators.BadBuddha_NewsMarkersPRO BadBuddha_NewsMarkersPRO(ISeries<double> input , NinjaTrader.NinjaScript.BBCountdownClock countdownClock, NinjaTrader.NinjaScript.BBTradingMode tradingMode, string csvFileName, int autoReloadMinutes, bool forceCSVDownload, string flagFolderName, int pastDays, int futureDays, bool showVerticalLines, int vLineOpacityPct, int vLineThicknessPx, bool showEventLabels, bool showCountdownLabels, int labelTitleMaxChars, bool enableBlackoutHigh, int highPreMinutes, int highPostMinutes, bool enableBlackoutMedium, int medPreMinutes, int medPostMinutes, int blackoutOpacityPct, bool enableCurrencyFilter, bool showUSD, bool showEUR, bool showGBP, bool showAUD, bool showNZD, bool showCAD, bool showCHF, bool showJPY, bool showCNY, bool enableUpdateCheck, bool showUpdatePopup, bool showEventsTable, BBTableDisplayMode tableDisplay, int tableMaxRows, int tableWidthPx, int tableRowHeightPx, int tableOpacityPct, NinjaTrader.NinjaScript.BBTableCorner tableCorner, int tableTitleMaxChars, int tableVerticalOffsetPx, bool showTableDataColumns, bool enableAlerts, bool alertHighImpact, bool alertMediumImpact, string alertWindowsCsv, string alertSoundFile, NinjaTrader.NinjaScript.Priority alertPriority, bool alertOnlyDuringTradingHours)
		{
			return indicator.BadBuddha_NewsMarkersPRO(input, countdownClock, tradingMode, csvFileName, autoReloadMinutes, forceCSVDownload, flagFolderName, pastDays, futureDays, showVerticalLines, vLineOpacityPct, vLineThicknessPx, showEventLabels, showCountdownLabels, labelTitleMaxChars, enableBlackoutHigh, highPreMinutes, highPostMinutes, enableBlackoutMedium, medPreMinutes, medPostMinutes, blackoutOpacityPct, enableCurrencyFilter, showUSD, showEUR, showGBP, showAUD, showNZD, showCAD, showCHF, showJPY, showCNY, enableUpdateCheck, showUpdatePopup, showEventsTable, tableDisplay, tableMaxRows, tableWidthPx, tableRowHeightPx, tableOpacityPct, tableCorner, tableTitleMaxChars, tableVerticalOffsetPx, showTableDataColumns, enableAlerts, alertHighImpact, alertMediumImpact, alertWindowsCsv, alertSoundFile, alertPriority, alertOnlyDuringTradingHours);
		}

	}
}

#endregion
